<?php
require_once __DIR__ . '/../templates/header.inc.php';
require_once __DIR__ . '/../templates/nav.inc.php';

//-------------------------------------------
?>

<h1>
Welcome to SmithIT Home Page
</h1>

<p>
This site offers you the chance to VOTE on your favourite DVD films ...
</p>


<?php
//-------------------------------------------
require_once __DIR__ . '/../templates/footer.inc.php';

//  don't close the PHP tags