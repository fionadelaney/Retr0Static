<?php
require_once __DIR__ . '/../templates/header.inc.php';
require_once __DIR__ . '/../templates/nav.inc.php';

//-------------------------------------------
?>

<h1>
    About us
</h1>

<p>
    We are SmithIT.com.
</p>
<p>
    We are based in Dublin.
</p>
<p>
    We were established in 2007.
</p>
<p>
    We sell computers and computer services - and host this great DVD voting site!.
</p>


<?php
//-------------------------------------------
require_once __DIR__ . '/../templates/footer.inc.php';

//  don't close the PHP tags