<?php

//------- important -------
// add this file to your .gitignore
//
// so we do NOT upload/publish our DB config to the cloud repository!
//----------------------------

// constants for our DB configuration
define('DB_HOST', 'localhost');
define('DB_USER', 'fred');
define('DB_PASS', 'smith');
define('DB_NAME', 'evote');